#include "window.h"

const char* window_title = "GLFW Starter Project";
GLfloat size;
int mode = 0;
int lightType = 1;
int movement = 0;
glm::vec3 lastpoint(0.0f,0.0f,0.0f);
double xpos, ypos;
Cube * cube;
OBJObject * toDisplay;
OBJObject * bunny;
OBJObject * bear;
OBJObject * dragon;
GLint shaderProgram;

glm::vec4 light(1.f,1.f,1.f,0.f);

glm::vec4 pl_dir(1.f,1.f,1.f,0.f);
GLfloat pl_scale = 3.0f;

glm::vec4 spot_dir(1.f,1.f,1.f,0.f);
GLfloat spot_scale = 3.0f;
float range = 0.8;
float spotExp = 1.f;

struct material {
    glm::vec4 spec;
    GLfloat shine;
    glm::vec4 mat;
    glm::vec4 amb;
} bunnyMat,bearMat,dragonMat;
struct material * currentMat = &bunnyMat;


// Default camera parameters
glm::vec3 cam_pos(0.0f, 0.0f, 20.0f);		// e  | Position of camera
glm::vec3 cam_look_at(0.0f, 0.0f, 0.0f);	// d  | This is where the camera looks at
glm::vec3 cam_up(0.0f, 1.0f, 0.0f);			// up | What orientation "up" is

int Window::width;
int Window::height;

glm::mat4 Window::P;
glm::mat4 Window::V;

void Window::initialize_objects()
{
	cube = new Cube();
    bunny = new OBJObject("bunny.obj");
    bear = new OBJObject("bear.obj");
    dragon = new OBJObject("dragon.obj");
    //bear = bunny;
    //dragon = bunny;
    toDisplay = bunny;
    
    
    bunnyMat.spec = glm::vec4(0.628281f,0.555802f,0.366065f,1.f);
    bunnyMat.shine = 51.2;
    bunnyMat.mat = glm::vec4(0.75164f,0.60648f,0.22648f,1.f);
    bunnyMat.amb = glm::vec4(0.24725f,0.1995f,0.0745f,1.f);
    
    bearMat.spec = glm::vec4(0.727811f,0.626959f,0.626959f,0.55f);
    bearMat.shine = 76.8;
    bearMat.mat = glm::vec4(0.61424f,0.04136f,0.04136f,0.55f);
    bearMat.amb = glm::vec4(0.1745f,0.01175f,0.01175f,0.55f);
    
    dragonMat.spec = glm::vec4(0.316228f,0.316228f,0.316228f,0.95f);
    dragonMat.shine = 12.8;
    dragonMat.mat = glm::vec4(0.54f,0.89f,0.63f,0.95f);
    dragonMat.amb = glm::vec4(0.135f,0.2225f,0.1575f,0.95f);

	// Load the shader program. Similar to the .obj objects, different platforms expect a different directory for files
#ifdef _WIN32 // Windows (both 32 and 64 bit versions)
	shaderProgram = LoadShaders("../shader.vert", "../shader.frag");
#else // Not windows
	shaderProgram = LoadShaders("shader.vert", "shader.frag");
#endif
}

void Window::clean_up()
{
	delete(cube);
    delete(bunny);
    delete(bear);
    delete(dragon);
	glDeleteProgram(shaderProgram);
}

GLFWwindow* Window::create_window(int width, int height)
{
	// Initialize GLFW
	if (!glfwInit())
	{
		fprintf(stderr, "Failed to initialize GLFW\n");
		return NULL;
	}

	// 4x antialiasing
	glfwWindowHint(GLFW_SAMPLES, 4);
    
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);

	// Create the GLFW window
	GLFWwindow* window = glfwCreateWindow(width, height, window_title, NULL, NULL);

	// Check if the window could not be created
	if (!window)
	{
		fprintf(stderr, "Failed to open GLFW window.\n");
		glfwTerminate();
		return NULL;
	}

	// Make the context of the window
	glfwMakeContextCurrent(window);

	// Set swap interval to 1
	glfwSwapInterval(1);

	// Get the width and height of the framebuffer to properly resize the window
	glfwGetFramebufferSize(window, &width, &height);
	// Call the resize callback to make sure things get drawn immediately
	Window::resize_callback(window, width, height);

	return window;
}

void Window::resize_callback(GLFWwindow* window, int width, int height)
{
	Window::width = width;
	Window::height = height;
	// Set the viewport size
	glViewport(0, 0, width, height);

	if (height > 0)
	{
		P = glm::perspective(45.0f, (float)width / (float)height, 0.1f, 1000.0f);
		V = glm::lookAt(cam_pos, cam_look_at, cam_up);
	}
}

void Window::idle_callback()
{
	// Call the update function the cube
	//cube->update();
    //toDisplay->update();
}

void Window::display_callback(GLFWwindow* window)
{
	// Clear the color and depth buffers
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    
    
	// Use the shader of programID
	glUseProgram(shaderProgram);
	
	// Render the cube
	toDisplay->draw(shaderProgram);
    //cube->draw(shaderProgram);

	// Gets events, including input such as keyboard and mouse or window resizing
	glfwPollEvents();
	// Swap buffers
	glfwSwapBuffers(window);
}

glm::vec3 Window::trackBallMapping(double xpos,double ypos)
{
    glm::vec3 v;
    float d;
    v.x = (2.0*xpos - Window::width) / Window::width;
    v.y = (Window::height - 2.0*ypos) / Window::height;
    v.z = 0.0;
    d = v.length();
    d = (d<1.0) ? d : 1.0;
    v.z = sqrtf(1.001 - d*d);
    v = glm::normalize(v);
    //v.Normalize(); // Still need to normalize, since we only capped d, not v.
    return v;
}
void Window::cursor_pos_callback(GLFWwindow* window, double x, double y)
{
    glm::vec3 direction;
    float rot_angle;
    glm::vec3 curPoint;
    if(mode ==0)
    {
        switch (movement)
        {
            
            case 1 : // Left-mouse button is being held down
            {
                curPoint = trackBallMapping(x,y); // Map the mouse position to a logical
                // sphere location.
                direction = curPoint - lastpoint;
                float velocity = direction.length();
                if( velocity > 0.0001 ) // If little movement - do nothing.
                {
                    glm::vec3 rotAxis;
                    rotAxis = glm::cross( lastpoint, curPoint );
                    rot_angle = velocity*0.02;
                    toDisplay->move(rot_angle,rotAxis);
                }
                break;
            }
            case 2:
            {
                toDisplay->move((xpos-x)*0.01,(ypos-y)*0.01);
                xpos = x;
                ypos = y;
                break;
            }
        }
        lastpoint = curPoint;
    }
    else
    {
        if(movement == 2)
        {
           if(lightType ==3)
           {
               if((y-ypos)>0)
                   range = range/1.1;
               else if((y-ypos)<0)
                   range = range*1.1;
               if((x-xpos)>0)
                   spotExp = spotExp/1.1;
               else if((x-xpos)<0)
                   spotExp = spotExp*1.1;

               xpos = x;
               ypos = y;
           }
        }
        else
        {
        if(lightType == 1)
        {
            lastpoint = trackBallMapping(x,y);
            light = glm::vec4(lastpoint,0.f);
        }
        else if(lightType ==2)
        {
            lastpoint = trackBallMapping(x,y);
            pl_dir = glm::vec4(lastpoint,0.f);
        }
        else if(lightType ==3)
        {
            lastpoint = trackBallMapping(x,y);
            spot_dir = glm::vec4(lastpoint,0.f);
        }
        }
    }
}
void Window::mouse_button_callback(GLFWwindow* window, int button, int action, int mods)
{
    if(mode ==0)
    {
        if (button == GLFW_MOUSE_BUTTON_LEFT && action == GLFW_PRESS)
        {
        
            glfwGetCursorPos(window, &xpos, &ypos);
            movement = 1;
            lastpoint = trackBallMapping(xpos,ypos);
        }
        if (button == GLFW_MOUSE_BUTTON_LEFT && action == GLFW_RELEASE)
        {
        
            movement = 0;
        }
        if (button == GLFW_MOUSE_BUTTON_RIGHT && action == GLFW_PRESS)
        {
            glfwGetCursorPos(window, &xpos, &ypos);
            movement = 2;
        
        }
        if (button == GLFW_MOUSE_BUTTON_RIGHT && action == GLFW_RELEASE)
        {
        
            movement = 0;
        }
    }
    else
    {
        if (button == GLFW_MOUSE_BUTTON_RIGHT && action == GLFW_PRESS)
        {
            glfwGetCursorPos(window, &xpos, &ypos);
            movement = 2;
            
        }
        if (button == GLFW_MOUSE_BUTTON_RIGHT && action == GLFW_RELEASE)
        {
            
            movement = 0;
        }

    }
    
    
}

void Window::scroll_callback(GLFWwindow* window, double xoffset, double yoffset)
{
    if(mode == 0)
    {
        if(yoffset >0)
            toDisplay->move('Z');
        else
            toDisplay->move('z');
    }
    else
    {
        if(lightType ==2)
        {
            if(yoffset >0)
                pl_scale = 1.1*pl_scale;
            else
                pl_scale = pl_scale/1.1;
        }
        if(lightType ==3)
        {
            if(yoffset >0)
                spot_scale = 1.2*pl_scale;
            else
                spot_scale = pl_scale/1.2;
        }
    }
}
void Window::key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    // Check for a key press
    if (action == GLFW_PRESS)
    {
        // Check if escape was pressed
        if (key == GLFW_KEY_ESCAPE)
        {
            // Close the window. This causes the program to also terminate.
            glfwSetWindowShouldClose(window, GL_TRUE);
        }
       
        glGetFloatv(GL_POINT_SIZE, &size);
        if( mods&GLFW_MOD_SHIFT )
        {
            if (key == GLFW_KEY_P)
            {
                glPointSize(size+1);
            }
            if (key == GLFW_KEY_X)
            {
                toDisplay->move('X');
            }
            if (key == GLFW_KEY_Y)
            {
                toDisplay->move('Y');
            }
            if (key == GLFW_KEY_Z)
            {
                toDisplay->move('Z');
            }
            if (key == GLFW_KEY_S)
            {
                toDisplay->move('S');
            }
            if (key == GLFW_KEY_O)
            {
                toDisplay->move('O');
            }
        }
        else
        {
            if (key == GLFW_KEY_P)
            {
                glPointSize(size-1);
            }
            if (key == GLFW_KEY_X)
            {
                toDisplay->move('x');
            }
            if (key == GLFW_KEY_Y)
            {
                toDisplay->move('y');
            }
            if (key == GLFW_KEY_Z)
            {
                toDisplay->move('z');
            }
            if (key == GLFW_KEY_S)
            {
                toDisplay->move('s');
            }
            if (key == GLFW_KEY_O)
            {
                toDisplay->move('o');
            }
            if (key == GLFW_KEY_R)
            {
                toDisplay->move('r');
            }
        }
        
        if (key == GLFW_KEY_F1)
        {
            toDisplay = bunny;
            currentMat = &bunnyMat;
            
        }
        if (key == GLFW_KEY_F2)
        {
            toDisplay = bear;
            currentMat = &bearMat;
            
        }
        if (key == GLFW_KEY_F3)
        {
            toDisplay = dragon;
            currentMat = &dragonMat;
            
        }
        if (key == GLFW_KEY_0)
        {
            if(mode ==0)
                mode = 1;
            else
                mode = 0;
        }
        if (key == GLFW_KEY_1)
        {
            lightType = 1;
            shaderProgram = LoadShaders("shader.vert", "shader.frag");
        }
        if (key == GLFW_KEY_2)
        {
            lightType = 2;
            shaderProgram = LoadShaders("shader_point.vert", "shader.frag");
        }
        if (key == GLFW_KEY_3)
        {
            lightType = 3;
            shaderProgram = LoadShaders("shader_spot.vert", "shader.frag");
        }
        
    }
}